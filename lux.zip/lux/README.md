Requires PHP >= 5.4

Include the following in the head of your page...
    <?php include $_SERVER['DOCUMENT_ROOT'].'/lux/luxgallery.php'; ?>
    
Instantiate a gallery anywhere in the body of your page...
    <?php luxGallery(); ?>
    
